Instructions on how to use the MoneySaver application:
	1. Double-click on the compiled .JAR file to run the java application.
	2. Input the total income/savings requested.
		a. If the savings/income combines to be negative or includes negative numbers, an error will display
		b. If the savings/income includes illegal characters (not numbers), an error will display
	3. Input the transaction name, amount, and select a type to add
	4. The graph will automatically update based off of the transaction type that is provided.
	5. Clearing/adjusting the income/savings will cause all of the transactions to be cleared.